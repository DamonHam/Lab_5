public class Task implements Priority {
	private String task;
	private int priority;
	
	public Task(String task, int priority) {
	    this.task = task;
	    setPriority(priority);
	}
	
	@Override
	public void setPriority(int priority) {
	    if (priority < 1 || priority > 5) {
	        throw new IllegalArgumentException("Priority must be between 1 and 5.");
	    }
	    this.priority = priority;
	}
	
	@Override
	public int getPriority() {
	    return priority;
	}
	
	public String getTask() {
	    return task;
	}
	
	@Override
	public String toString() {
	    return task + "          priority: " + priority;
	}
}
