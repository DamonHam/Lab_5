public interface Priority {
	void setPriority(int priority);
	int getPriority();
}